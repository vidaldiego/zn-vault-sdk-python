# Path: zn-vault-sdk-python/src/znvault/auth/__init__.py
"""Authentication client module."""

from znvault.auth.client import AuthClient

__all__ = ["AuthClient"]
