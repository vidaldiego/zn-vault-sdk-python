# Path: zn-vault-sdk-python/src/znvault/audit/__init__.py
"""Audit client module."""

from znvault.audit.client import AuditClient

__all__ = ["AuditClient"]
