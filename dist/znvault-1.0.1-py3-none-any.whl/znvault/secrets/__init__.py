# Path: zn-vault-sdk-python/src/znvault/secrets/__init__.py
"""Secrets client module."""

from znvault.secrets.client import SecretsClient

__all__ = ["SecretsClient"]
